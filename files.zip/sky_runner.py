"""
Sky Runner - a doodle-jump style game drawn in a shaky MS Paint look.

Run:   python sky_runner.py
Needs: pygame 2.x   (pip install pygame)

Controls: Left/Right arrows or A/D (or hold the mouse on the left/right half)
          Space / Enter / click to start and restart.   Esc to quit.
"""
import json
import math
import os
import random
import sys

import pygame

W, H = 400, 600
FPS = 60
SAVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "skyrunner_best.json")

PAPER = [(255, 254, 245), (232, 244, 255), (255, 240, 220), (241, 233, 255), (229, 251, 232)]
GRID = [(188, 215, 240), (183, 205, 230), (239, 201, 160), (205, 185, 238), (168, 219, 176)]

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (34, 177, 76)
BLUE = (0, 162, 232)
BROWN = (185, 122, 87)
RED = (237, 28, 36)
YELLOW = (255, 242, 0)
BODY = (255, 228, 92)
ORANGE = (255, 127, 39)
SKY = (153, 217, 234)

LEVEL_HEIGHT = 2200


def rand(a, b):
    return random.uniform(a, b)


def jit():
    return [rand(-2.5, 2.5) for _ in range(10)]


# ---------------------------------------------------------------- drawing --
def poly(surf, pts, fill=None):
    if fill:
        pygame.draw.polygon(surf, fill, pts)
    pygame.draw.lines(surf, BLACK, True, pts, 3)
    for p in pts:  # round off the corners like a paint brush
        pygame.draw.circle(surf, BLACK, (int(p[0]), int(p[1])), 1)


def rrect(surf, x, y, w, h, j, fill):
    poly(surf, [
        (x + j[0], y + j[1]),
        (x + w / 2 + j[2], y + j[3] * .5),
        (x + w + j[4], y + j[5]),
        (x + w + j[6], y + h + j[7]),
        (x + w / 2 + j[8], y + h + j[9] * .5),
        (x + j[1], y + h + j[3]),
    ], fill)


def star(surf, x, y, r, fill):
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r * .45 if i % 2 else r
        pts.append((x + math.cos(a) * rr, y + math.sin(a) * rr))
    poly(surf, pts, fill)


_fonts = {}


def font(size, bold=True):
    key = (size, bold)
    if key not in _fonts:
        _fonts[key] = pygame.font.SysFont("comicsansms,chalkboardse,markerfelt,comicneue,dejavusans",
                                          int(size), bold=bold)
    return _fonts[key]


def text(surf, s, x, y, size, align="left", fill=WHITE, angle=0):
    """Chunky outlined text. (x, y) is the left/centre/right baseline point."""
    f = font(size)
    t = max(2, int(size // 9))
    base = f.render(s, True, fill)
    out = f.render(s, True, BLACK)
    w, h = base.get_size()
    img = pygame.Surface((w + 2 * t, h + 2 * t), pygame.SRCALPHA)
    for k in range(16):
        a = k * math.pi / 8
        img.blit(out, (t + math.cos(a) * t, t + math.sin(a) * t))
    img.blit(base, (t, t))
    if angle:
        img = pygame.transform.rotate(img, angle)
    r = img.get_rect()
    cy = y - f.get_ascent() + h / 2
    cx = x if align == "center" else (x + w / 2 if align == "left" else x - w / 2)
    r.center = (cx, cy)
    surf.blit(img, r)


def plain(surf, s, x, y, size):
    f = font(size, bold=False)
    img = f.render(s, True, BLACK)
    r = img.get_rect()
    r.midtop = (x, y - f.get_ascent())
    surf.blit(img, r)


def draw_player(surf, x, y, face, vy):
    sq = 1.08 if vy < 0 else .95

    def T(px, py):
        return (x + px, y + py * sq)

    pygame.draw.line(surf, BLACK, T(-8, -8), T(-10, 0), 3)
    pygame.draw.line(surf, BLACK, T(8, -8), T(10, 0), 3)
    pygame.draw.line(surf, BLACK, T(-14, 0), T(-6, 0), 3)
    pygame.draw.line(surf, BLACK, T(6, 0), T(14, 0), 3)
    poly(surf, [T(-13, -10), T(-15, -26), T(-9, -34), T(0, -36), T(9, -34),
                T(15, -26), T(13, -10), T(0, -7)], BODY)
    poly(surf, [T(face * 8, -24), T(face * 22, -20), T(face * 22, -15), T(face * 10, -14)], BODY)
    eye = T(face * 3, -26)
    pygame.draw.circle(surf, WHITE, (int(eye[0]), int(eye[1])), 5)
    pygame.draw.circle(surf, BLACK, (int(eye[0]), int(eye[1])), 5, 2)
    pupil = T(face * 5, -26)
    pygame.draw.circle(surf, BLACK, (int(pupil[0]), int(pupil[1])), 2)


def draw_foe(surf, x, y):
    pts = []
    for i in range(16):
        a = i * math.pi / 8
        r = 13 if i % 2 else 21
        pts.append((x + math.cos(a) * r, y + math.sin(a) * r))
    poly(surf, pts, RED)
    for o in (-6, 6):
        pygame.draw.circle(surf, WHITE, (int(x + o), int(y - 3)), 4)
        pygame.draw.circle(surf, BLACK, (int(x + o), int(y - 3)), 4, 2)
        pygame.draw.circle(surf, BLACK, (int(x + o), int(y - 2)), 2)
    pygame.draw.line(surf, BLACK, (x - 11, y - 11), (x - 2, y - 7), 3)
    pygame.draw.line(surf, BLACK, (x + 11, y - 11), (x + 2, y - 7), 3)
    pygame.draw.lines(surf, BLACK, False, [(x - 6, y + 9), (x, y + 6), (x + 6, y + 9)], 3)


# ------------------------------------------------------------------- game --
class Game:
    def __init__(self):
        self.best = self.load_best()
        self.state = "title"
        self.t = 0
        self.reset()
        self.state = "title"
        self.btn_j = jit()

    # persistence
    def load_best(self):
        try:
            with open(SAVE_FILE) as fh:
                return int(json.load(fh).get("best", 0))
        except Exception:
            return 0

    def save_best(self):
        try:
            with open(SAVE_FILE, "w") as fh:
                json.dump({"best": self.best}, fh)
        except Exception:
            pass

    # setup
    def reset(self):
        self.px, self.py, self.pvx, self.pvy, self.face = 200.0, -20.0, 0.0, -9.0, 1
        self.prev_y = -20.0
        self.plats = [dict(x=130, y=0, w=140, type=0, dx=0, j=jit(), broken=False, fall=0)]
        self.stars = []
        self.foes = []
        self.cam_y = -400.0
        self.top_y = 0.0
        self.max_h = 0.0
        self.bonus = 0
        self.level = 1
        self.banner = 0
        self.last_break = False
        self.fill()

    def start(self):
        self.reset()
        self.state = "play"

    def score(self):
        return int(self.max_h // 10) + self.bonus

    def die(self):
        self.state = "over"
        s = self.score()
        if s > self.best:
            self.best = s
            self.save_best()

    def fill(self):
        while self.top_y > self.cam_y - 120:
            gap = min(62 + self.level * 9, 118) + rand(-8, 8)
            self.top_y -= gap
            w = max(80 - self.level * 4, 50)
            x = rand(10, W - w - 10)
            ptype, dx = 0, 0
            r = random.random()
            mv = min(.12 + self.level * .05, .4)
            br = min(self.level * .05, .25)
            if self.level > 1 and r < mv:
                ptype = 1
                dx = random.choice((-1, 1)) * (1 + self.level * .25)
            elif self.level > 1 and r < mv + br and not self.last_break:
                ptype = 2
            self.last_break = ptype == 2
            self.plats.append(dict(x=x, y=self.top_y, w=w, type=ptype, dx=dx,
                                   j=jit(), broken=False, fall=0))
            if random.random() < .14:
                self.stars.append(dict(x=x + w / 2, y=self.top_y - 40))
            if self.level >= 2 and random.random() < .05 + self.level * .012:
                self.foes.append(dict(x=rand(40, W - 40), y=self.top_y - gap / 2,
                                      ph=rand(0, 6)))

    # update
    def step(self, direction):
        self.t += 1
        direction = max(-1, min(1, direction))
        self.pvx += (direction * 5 - self.pvx) * .25
        if direction:
            self.face = direction
        self.prev_y = self.py
        self.px += self.pvx
        self.pvy += .45
        self.py += self.pvy
        if self.px < -10:
            self.px = W + 10
        if self.px > W + 10:
            self.px = -10
        self.max_h = max(self.max_h, -self.py)
        nl = 1 + int(self.max_h // LEVEL_HEIGHT)
        if nl > self.level:
            self.level = nl
            self.banner = 130
        if self.banner > 0:
            self.banner -= 1
        self.cam_y = min(self.cam_y, self.py - 320)

        for q in self.plats:
            if q["type"] == 1:
                q["x"] += q["dx"]
                if q["x"] < 0 or q["x"] + q["w"] > W:
                    q["dx"] *= -1
            if q["broken"]:
                q["fall"] += 5
                continue
            if (self.pvy > 0 and self.prev_y <= q["y"] + 2 and self.py >= q["y"]
                    and self.px + 12 > q["x"] and self.px - 12 < q["x"] + q["w"]):
                if q["type"] == 2:
                    q["broken"] = True
                else:
                    self.pvy = -12.6

        for s in self.stars[:]:
            if math.hypot(self.px - s["x"], self.py - 17 - s["y"]) < 28:
                self.stars.remove(s)
                self.bonus += 50

        for f in self.foes[:]:
            ey = f["y"] + math.sin(self.t * .05 + f["ph"]) * 10
            if math.hypot(self.px - f["x"], self.py - 17 - ey) < 30:
                if self.pvy > 0 and self.py - 8 < ey:
                    self.foes.remove(f)
                    self.pvy = -11
                    self.bonus += 100
                else:
                    self.die()
                    return

        if self.py - self.cam_y > H + 40:
            self.die()
            return
        self.fill()
        limit = self.cam_y + H + 200
        self.plats = [q for q in self.plats if q["y"] < limit]
        self.stars = [s for s in self.stars if s["y"] < limit]
        self.foes = [f for f in self.foes if f["y"] < limit]

    # render
    def draw(self, surf):
        i = (self.level - 1) % len(PAPER)
        surf.fill(PAPER[i])
        off = (-self.cam_y) % 24
        y = off - 24
        while y < H:
            pygame.draw.line(surf, GRID[i], (0, y), (W, y))
            y += 24
        for x in range(0, W, 24):
            pygame.draw.line(surf, GRID[i], (x, 0), (x, H))

        for q in self.plats:
            self.draw_plat(surf, q)
        for s in self.stars:
            star(surf, s["x"], s["y"] - self.cam_y, 13 + math.sin(self.t * .1) * 1.5, YELLOW)
        for f in self.foes:
            draw_foe(surf, f["x"], f["y"] - self.cam_y + math.sin(self.t * .05 + f["ph"]) * 10)

        if self.state != "title":
            draw_player(surf, self.px, self.py - self.cam_y, self.face, self.pvy)

        if self.state in ("play", "over"):
            text(surf, "Score %d" % self.score(), 12, 32, 24, "left", YELLOW)
            text(surf, "Level %d" % self.level, W - 12, 32, 24, "right", SKY)
            prog = (self.max_h % LEVEL_HEIGHT) / LEVEL_HEIGHT
            pygame.draw.rect(surf, WHITE, (W - 112, 42, 100, 10))
            pygame.draw.rect(surf, GREEN, (W - 112, 42, 100 * prog, 10))
            pygame.draw.rect(surf, BLACK, (W - 112, 42, 100, 10), 2)
            if self.banner > 0 and self.state == "play":
                text(surf, "LEVEL %d!" % self.level, W / 2, 170, 54, "center", ORANGE, 3.4)

        if self.state == "title":
            text(surf, "SKY RUNNER", W / 2, 150, 58, "center", BLUE, 2.9)
            plain(surf, "Bounce up the clouds. Grab stars.", W / 2, 215, 19)
            plain(surf, "Stomp the red spikies from above.", W / 2, 240, 19)
            plain(surf, "Go higher to clear each level.", W / 2, 265, 19)
            plain(surf, "Move: \u2190 \u2192 or A D, or hold the mouse left/right", W / 2, 305, 15)
            rrect(surf, 110, 470, 180, 56, self.btn_j, GREEN)
            text(surf, "PLAY", W / 2, 510, 32, "center", WHITE)
            if self.best:
                plain(surf, "Best: %d" % self.best, W / 2, 560, 18)
            draw_player(surf, 200, 420, 1, 0)

        if self.state == "over":
            veil = pygame.Surface((W, H), pygame.SRCALPHA)
            veil.fill((255, 255, 255, 140))
            surf.blit(veil, (0, 0))
            text(surf, "OOPS!", W / 2, 200, 64, "center", RED, -2.9)
            plain(surf, "Score %d  \u00b7  Level %d" % (self.score(), self.level), W / 2, 260, 24)
            new = " (new!)" if self.score() >= self.best and self.score() > 0 else ""
            plain(surf, "Best %d%s" % (self.best, new), W / 2, 295, 22)
            rrect(surf, 110, 350, 180, 56, self.btn_j, BLUE)
            text(surf, "AGAIN", W / 2, 390, 32, "center", WHITE)
            plain(surf, "click or press Space", W / 2, 440, 16)

    def draw_plat(self, surf, q):
        y = q["y"] - self.cam_y
        col = (GREEN, BLUE, BROWN)[q["type"]]
        target, ox, oy = surf, 0, 0
        if q["broken"]:
            target = pygame.Surface((int(q["w"]) + 20, 40), pygame.SRCALPHA)
            ox, oy = 10 - q["x"], 10 - y
        rrect(target, q["x"] + ox, y + oy, q["w"], 14, q["j"], col)
        if q["type"] == 2:
            x0 = q["x"] + ox
            pygame.draw.lines(target, BLACK, False, [
                (x0 + q["w"] * .4, y + oy), (x0 + q["w"] * .5, y + oy + 8),
                (x0 + q["w"] * .45, y + oy + 14)], 2)
        if q["broken"]:
            alpha = max(0, int(255 * (1 - q["fall"] / 200)))
            target.set_alpha(alpha)
            surf.blit(target, (q["x"] - 10, y - 10 + q["fall"]))


def main():
    pygame.init()
    pygame.display.set_caption("Sky Runner")
    flags = pygame.SCALED | pygame.RESIZABLE
    try:
        screen = pygame.display.set_mode((W, H), flags)
    except pygame.error:
        screen = pygame.display.set_mode((W, H))
    clock = pygame.time.Clock()
    game = Game()

    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if e.key in (pygame.K_SPACE, pygame.K_RETURN) and game.state != "play":
                    game.start()
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and game.state != "play":
                game.start()

        direction = 0
        k = pygame.key.get_pressed()
        if k[pygame.K_LEFT] or k[pygame.K_a]:
            direction -= 1
        if k[pygame.K_RIGHT] or k[pygame.K_d]:
            direction += 1
        if pygame.mouse.get_pressed()[0] and game.state == "play":
            direction += -1 if pygame.mouse.get_pos()[0] < W / 2 else 1

        if game.state == "play":
            game.step(direction)
        else:
            game.t += 1
        game.draw(screen)
        pygame.display.flip()
        clock.tick(FPS)


if __name__ == "__main__":
    main()
